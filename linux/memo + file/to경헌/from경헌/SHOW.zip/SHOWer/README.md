## Introduction

Spring framework 기반 Springmvc와 mybatis를 이용한

영화, 공연 등에 대한 정보제공과 사용자들의 리뷰를 공유할 수 있는 웹 서비스

## 사용한 SW

![1563439321646](img/1563439321646.png)

## 기능

![1563439382808](img/1563439382808.png)



## 시스템 구성

![1563439418904](img/1563439418904.png)

## DataBase ERD

![1563439467014](img/1563439467014.png)

## UI 흐름도

![1563439510223](img/1563439510223.png)



## .

![1563439590762](img/1563439590762.png)

![1563439607311](img/1563439607311.png)

![1563439640319](../../../../AppData/Roaming/Typora/typora-user-images/1563439640319.png)

![1563439718546](../../../../AppData/Roaming/Typora/typora-user-images/1563439718546.png)

